# Core Media

Static frontend for the Core Media website and admin panel.

## Data model

- Supabase is the source of truth for `public.cm_brands` and `public.cm_site_settings`.
- The project catalog is not embedded in `index.html`; empty database results are treated as an intentional empty state.
- The browser cache is a last-known snapshot for temporary display during a connection outage only. It is never used to repopulate Supabase.
- Admin edits are considered saved only after Supabase confirms the write.
- Deleting media or a project attempts to remove the underlying Storage object only when no other project or site setting references it.
- The admin panel includes a confirmed scan for orphaned objects in the `cm-portfolio` bucket.

## Local run

1. Configure `supabase-config.js` with the project URL and publishable/anon key. Never place a service-role key in frontend files.
2. Run `run-server.bat` on Windows, or serve this directory with any local static web server.
3. Open `/` for the website and `/admin.html` for the admin panel.
4. Configure the tables, RLS policies, Storage bucket, and admin user using `supabase-setup.sql` and `SETUP_SUPABASE.md`.

## Deployment

Deploy the updated project from GitHub to Vercel. Removed legacy media folders were only used by the former static portfolio catalog; the live catalog now comes from Supabase.
